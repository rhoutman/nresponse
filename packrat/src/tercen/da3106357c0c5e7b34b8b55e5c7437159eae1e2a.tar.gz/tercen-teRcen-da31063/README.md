# Tercen R client

## Install teRcen package

First install [rtson](https://github.com/tercen/TSON/tree/master/rtson).

```R
install.packages('devtools')
devtools::install_github("tercen/teRcen", ref = "0.8.5", upgrade_dependencies = FALSE, args="--no-multiarch")
```